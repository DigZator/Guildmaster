const { ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { buildByCharacterEmbed, buildByRewardEmbed } = require('../utils/questReportEmbed');
const { encodeId } = require('./questDashboardId');
const { getQuestById } = require('../commands/leagueQuest');
const { getPageById } = require('../utils/leagueNotion');
const questDrafts = require('../utils/questDrafts');

const GROUPINGS = Object.freeze(['character', 'reward']);

async function loadDashboardState(questId, requestingUser) {
    const upperId = questId.toUpperCase();

    const quest = await getQuestById(upperId);
    if (!quest) {
        throw new Error(`❌ No quest found with ID \`${upperId}\`.`);
    }

    const questName    = quest.properties['Adventure Name']?.title?.[0]?.plain_text ?? 'Unknown';
    const characterIds = quest.properties['Characters']?.relation?.map(r => r.id) ?? [];

    const characterPages = await Promise.all(
        characterIds.map(id => getPageById(id).catch(() => null))
    );

    const roster = characterPages
        .filter(Boolean)
        .map(char => ({
            characterPageId: char.id,
            characterName: char.properties['Character Name']?.title?.[0]?.plain_text ?? 'Unknown',
            discordId: char.properties['Discord ID']?.rich_text?.[0]?.plain_text ?? null,
        }));

    const draft = questDrafts.getOrCreateDraft(upperId, {
        questPageId: quest.id,
        questName,
        dm: requestingUser ?? null,
    });

    return { quest, questId: upperId, questName, roster, draft };
}

function buildEmbed(draft, roster, grouping) {
    return grouping === 'reward'
        ? buildByRewardEmbed(draft, roster)
        : buildByCharacterEmbed(draft, roster);
}

function buildActionRows(questId, { locked }) {
    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'addReward'))
            .setLabel('Rewards')
            .setStyle(ButtonStyle.Success)
            .setDisabled(locked),
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'editParty'))
            .setLabel('Edit Party')
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(locked),
    );

    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'submit'))
            .setLabel('Submit Report')
            .setStyle(ButtonStyle.Primary)
            .setDisabled(locked),
    );

    return [row1, row2];
}

function buildGroupingRow(questId, grouping) {
    const next = grouping === 'reward' ? 'character' : 'reward';
    const label = next === 'reward' ? '🔄 Group by Reward Type' : '🔄 Group by Character';

    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'toggleGroup', next))
            .setLabel(label)
            .setStyle(ButtonStyle.Secondary),
    );
}

function renderMainView(draft, roster, { grouping = 'character' } = {}) {
    if (!GROUPINGS.includes(grouping)) {
        throw new Error(`[questDashboardRender] Unknown grouping "${grouping}". Expected one of: ${GROUPINGS.join(', ')}`);
    }

    const locked = draft.status !== 'draft';
    const embed = buildEmbed(draft, roster, grouping);

    if (locked) {
        embed.setDescription(
            (embed.data.description ? `${embed.data.description}\n\n` : '') +
            `_This report has been submitted (status: **${draft.status}**) and is no longer editable here._`
        );
    }

    return {
        embeds: [embed],
        components: [
            ...buildActionRows(draft.questId, { locked }),
            buildGroupingRow(draft.questId, grouping),
        ],
    };
}

module.exports = {
    GROUPINGS,
    renderMainView,
    loadDashboardState,
};
