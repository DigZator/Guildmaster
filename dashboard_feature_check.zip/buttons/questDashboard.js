const {
    ActionRowBuilder, ButtonBuilder, ButtonStyle,
    StringSelectMenuBuilder, UserSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
} = require('discord.js');
const { decodeId, encodeId } = require('../interactions/questDashboardId');
const { loadDashboardState, renderMainView } = require('../interactions/questDashboardRender');
const { buildByCharacterEmbed } = require('../utils/questReportEmbed');
const { addAction } = require('../utils/pendingActions');
const { sendAdminLog } = require('../utils/adminLog');
const questDrafts = require('../utils/questDrafts');
const { REP_MAX } = require('../commands/leagueGrants');
const { searchCatalogue, getCatalogueItemByCode, defaultPriceFor, inferSubtype } = require('../utils/5etoolsCatalogue');
const { formatCurrency } = require('../utils/currency');
const { getActiveCharacter } = require('../utils/leagueNotion');
const { addCharacterToRoster, removeCharactersFromRoster } = require('../commands/leagueQuest');

const BULK_PAGE_SIZE = 5; 
const REWARD_TYPE_LABELS = { gold: 'Gold', rep: 'Reputation', milestone: 'Milestones', item: 'Item' };

function assertOwner(state, interaction) {
    const ownerId = state.draft.dm?.discordId;
    if (ownerId && ownerId !== interaction.user.id) {
        throw new Error(`❌ Only <@${ownerId}> (the DM who started this draft) can edit this report.`);
    }
}

function assertUnlocked(state) {
    if (state.draft.status !== 'draft') {
        throw new Error(`❌ This report is already \`${state.draft.status}\` — refresh the dashboard with \`/leaguedm dashboard\` to see its current state.`);
    }
}

async function refreshDashboardMessage(interaction, questId, dashboardMessageId) {
    if (!dashboardMessageId) return;
    try {
        const dashboardMessage = await interaction.channel.messages.fetch(dashboardMessageId);
        const refreshed = await loadDashboardState(questId, null);
        await dashboardMessage.edit(renderMainView(refreshed.draft, refreshed.roster));
    } catch (err) {
        console.warn(`[questDashboard] Could not refresh original dashboard message ${dashboardMessageId}:`, err.message);
    }
}

// Submit Report

async function handleSubmit(interaction, questId) {
    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
    } catch (err) {
        return interaction.reply({ content: err.message, flags: 64 });
    }

    try {
        assertOwner(state, interaction);
    } catch (err) {
        return interaction.reply({ content: err.message, flags: 64 });
    }

    if (state.draft.status !== 'draft') {
        return interaction.reply({
            content: `❌ This report is already \`${state.draft.status}\` — nothing to submit. Refresh the dashboard with \`/leaguedm dashboard\`.`,
            flags: 64,
        });
    }

    if (state.draft.lines.length === 0) {
        return interaction.reply({
            content: '❌ Nothing queued yet — add at least one reward before submitting.',
            flags: 64,
        });
    }

    // don't require every roster character to have a line — warn instead.
    const charactersWithLines = new Set(state.draft.lines.map(l => l.characterPageId));
    const missing = state.roster.filter(c => !charactersWithLines.has(c.characterPageId));

    const embed = buildByCharacterEmbed(state.draft, state.roster)
        .setTitle(`Confirm Submission — ${state.questName} (\`${state.questId}\`)`);

    if (missing.length > 0) {
        embed.addFields({
            name: '⚠️ No rewards queued for',
            value: missing.map(c => c.characterName).join(', '),
            inline: false,
        });
    }

    const dashboardMessageId = interaction.message.id;
    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'submitConfirm', dashboardMessageId))
            .setLabel('Confirm Submit')
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'submitCancel', dashboardMessageId))
            .setLabel('Cancel')
            .setStyle(ButtonStyle.Secondary),
    );

    return interaction.reply({ embeds: [embed], components: [row], flags: 64 });
}

async function handleSubmitConfirm(interaction, questId, dashboardMessageId) {
    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
    } catch (err) {
        return interaction.update({ content: err.message, embeds: [], components: [] });
    }

    try {
        assertOwner(state, interaction);
    } catch (err) {
        return interaction.update({ content: err.message, embeds: [], components: [] });
    }

    if (state.draft.status !== 'draft') {
        return interaction.update({
            content: `⚠️ This report was already \`${state.draft.status}\` (probably a duplicate click) — nothing more to do.`,
            embeds: [],
            components: [],
        });
    }

    if (state.draft.lines.length === 0) {
        return interaction.update({
            content: '❌ Nothing queued anymore — the draft was cleared before this was confirmed.',
            embeds: [],
            components: [],
        });
    }

    const entry = addAction({
        type: 'quest-report',
        dm: state.draft.dm ?? { discordId: interaction.user.id, username: interaction.user.username },
        quest: { questId: state.questId, questName: state.questName, questPageId: state.quest.id },
        payload: { lines: questDrafts.snapshotLines(state.questId) },
    });

    questDrafts.setStatus(state.questId, questDrafts.STATUSES.SUBMITTED);
    const submittedDraft = questDrafts.getDraft(state.questId);

    await sendAdminLog(interaction.guild, buildByCharacterEmbed(submittedDraft, state.roster)
        .setTitle(`⏳ Quest Report — Pending (${state.questName} \`${state.questId}\`)`)
        .addFields(
            { name: 'Requested By', value: `<@${interaction.user.id}>`, inline: true },
            { name: 'Action ID',    value: `\`${entry.id}\``,           inline: true },
        ));

    await refreshDashboardMessage(interaction, state.questId, dashboardMessageId);

    return interaction.update({
        content: `✅ Report submitted for admin review (\`${entry.id}\`).`,
        embeds: [],
        components: [],
    });
}

async function handleSubmitCancel(interaction) {
    return interaction.update({ content: 'Submission cancelled — nothing changed.', embeds: [], components: [] });
}

// Add Reward — step 1: reward-type select

async function handleAddReward(interaction, questId) {
    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.reply({ content: err.message, flags: 64 });
    }

    if (state.roster.length === 0) {
        return interaction.reply({ content: '❌ This quest has no characters yet — add characters before queuing rewards.', flags: 64 });
    }

    const dashboardMessageId = interaction.message.id;
    const select = new StringSelectMenuBuilder()
        .setCustomId(encodeId(questId, 'addRewardType', dashboardMessageId))
        .setPlaceholder('What kind of reward?')
        .addOptions(
            { label: 'Gold',         value: 'gold',      emoji: '💰' },
            { label: 'Reputation',   value: 'rep',       emoji: '⭐' },
            { label: 'Milestones',   value: 'milestone', emoji: '🏆' },
            { label: 'Item',         value: 'item',       emoji: '🎒' },
        );

    return interaction.reply({
        content: 'What kind of reward do you want to add?',
        components: [new ActionRowBuilder().addComponents(select)],
        flags: 64,
    });
}

// Add Reward — gold / rep / milestone: bulk per-character modal, paginated

function existingAmount(draft, characterPageId, type) {
    const line = draft.lines.find(l => l.characterPageId === characterPageId && l.type === type);
    return line?.payload?.amount ?? 0;
}

function buildBulkAmountModal(questId, rewardType, pageIndex, dashboardMessageId, charactersSlice, draft, totalPages) {
    const modal = new ModalBuilder()
        .setCustomId(encodeId(questId, 'addRewardBulk', `${rewardType}|${pageIndex}|${dashboardMessageId}`))
        .setTitle(`${REWARD_TYPE_LABELS[rewardType]} Rewards${totalPages > 1 ? ` (Page ${pageIndex + 1}/${totalPages})` : ''}`.slice(0, 45));

    for (let i = 0; i < charactersSlice.length; i++) {
        const character = charactersSlice[i];
        const current = existingAmount(draft, character.characterPageId, rewardType);
        modal.addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId(`amt${i}`)
                    .setLabel(character.characterName.slice(0, 45))
                    .setStyle(TextInputStyle.Short)
                    .setRequired(false)
                    .setValue(String(current))
                    .setPlaceholder('0'),
            ),
        );
    }

    return modal;
}

async function handleAddRewardTypeSelect(interaction, questId, dashboardMessageId) {
    const rewardType = interaction.values[0];

    if (rewardType === 'item') {
        return showItemPlayerSelect(interaction, questId, dashboardMessageId);
    }

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    const totalPages = Math.ceil(state.roster.length / BULK_PAGE_SIZE);
    const slice = state.roster.slice(0, BULK_PAGE_SIZE);
    const modal = buildBulkAmountModal(questId, rewardType, 0, dashboardMessageId, slice, state.draft, totalPages);

    return interaction.showModal(modal);
}

async function handleAddRewardBulkModalSubmit(interaction, questId, extra) {
    const [rewardType, pageIndexStr, dashboardMessageId] = extra.split('|');
    const pageIndex = parseInt(pageIndexStr, 10);

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.reply({ content: err.message, flags: 64 });
    }

    const slice = state.roster.slice(pageIndex * BULK_PAGE_SIZE, pageIndex * BULK_PAGE_SIZE + BULK_PAGE_SIZE);
    const results = [];

    for (let i = 0; i < slice.length; i++) {
        const character = slice[i];
        const raw = interaction.fields.getTextInputValue(`amt${i}`).trim();
        const amount = raw === '' ? 0 : parseInt(raw, 10);

        if (isNaN(amount)) {
            results.push(`❌ **${character.characterName}** — "${raw}" isn't a number, skipped.`);
            continue;
        }
        if (rewardType === 'gold' && amount < 0) {
            results.push(`❌ **${character.characterName}** — DMs cannot grant negative gold, skipped.`);
            continue;
        }
        if (rewardType === 'rep' && amount > REP_MAX) {
            results.push(`❌ **${character.characterName}** — exceeds max (${REP_MAX}) reputation, skipped. Contact a mod.`);
            continue;
        }

        const existingLine = state.draft.lines.find(l => l.characterPageId === character.characterPageId && l.type === rewardType);

        if (amount === 0) {
            if (existingLine) {
                questDrafts.removeLine(questId, existingLine.lineId);
                results.push(`🗑️ **${character.characterName}** — cleared.`);
            }
            continue;
        }

        questDrafts.addOrReplaceLine(questId, {
            characterPageId: character.characterPageId,
            characterName: character.characterName,
            discordId: character.discordId,
            type: rewardType,
            payload: { amount },
        });
        results.push(`✅ **${character.characterName}** — set to ${amount}.`);
    }

    const nextPageIndex = pageIndex + 1;
    const hasMorePages = nextPageIndex * BULK_PAGE_SIZE < state.roster.length;

    if (hasMorePages) {
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(encodeId(questId, 'addRewardBulkNext', `${rewardType}|${nextPageIndex}|${dashboardMessageId}`))
                .setLabel(`Continue (${REWARD_TYPE_LABELS[rewardType]})`)
                .setStyle(ButtonStyle.Primary),
        );
        return interaction.reply({
            content: `${results.join('\n')}\n\nMore characters to go — click Continue.`,
            components: [row],
            flags: 64,
        });
    }

    await refreshDashboardMessage(interaction, questId, dashboardMessageId);
    return interaction.reply({ content: `${results.join('\n')}\n\n✅ Done.`, flags: 64 });
}

async function handleAddRewardBulkNext(interaction, questId, extra) {
    const [rewardType, pageIndexStr, dashboardMessageId] = extra.split('|');
    const pageIndex = parseInt(pageIndexStr, 10);

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.reply({ content: err.message, flags: 64 });
    }

    const totalPages = Math.ceil(state.roster.length / BULK_PAGE_SIZE);
    const slice = state.roster.slice(pageIndex * BULK_PAGE_SIZE, pageIndex * BULK_PAGE_SIZE + BULK_PAGE_SIZE);

    if (slice.length === 0) {
        return interaction.reply({ content: '❌ No more characters on this page — the roster may have changed. Reopen Add Reward to try again.', flags: 64 });
    }

    const modal = buildBulkAmountModal(questId, rewardType, pageIndex, dashboardMessageId, slice, state.draft, totalPages);
    return interaction.showModal(modal);
}

// Add Reward — item: player select → add/remove → modal or removal select

async function showItemPlayerSelect(interaction, questId, dashboardMessageId) {
    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    const options = state.roster.slice(0, 25).map(c => ({ label: c.characterName.slice(0, 100), value: c.characterPageId }));
    const select = new StringSelectMenuBuilder()
        .setCustomId(encodeId(questId, 'addItemPlayer', dashboardMessageId))
        .setPlaceholder('Which character?')
        .addOptions(options);

    return interaction.update({
        content: 'Which character is this item for?',
        components: [new ActionRowBuilder().addComponents(select)],
    });
}

async function handleAddItemPlayerSelect(interaction, questId, dashboardMessageId) {
    const characterPageId = interaction.values[0];

    const select = new StringSelectMenuBuilder()
        .setCustomId(encodeId(questId, 'addItemAction', `${characterPageId}|${dashboardMessageId}`))
        .setPlaceholder('Add or remove an item?')
        .addOptions(
            { label: 'Add Item',    value: 'add',    emoji: '➕' },
            { label: 'Remove Item', value: 'remove', emoji: '➖' },
        );

    return interaction.update({
        content: 'Add a new item, or remove one already queued?',
        components: [new ActionRowBuilder().addComponents(select)],
    });
}

function buildManualItemModal(questId, characterPageId, dashboardMessageId, sourceTag, prefill = {}) {
    const modal = new ModalBuilder()
        .setCustomId(encodeId(questId, 'addItemModal', `${characterPageId}|${dashboardMessageId}|${sourceTag}`))
        .setTitle(sourceTag === 'catalogue' ? 'Confirm Item' : 'Add Item (Manual)')
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('itemName').setLabel('Item Name').setStyle(TextInputStyle.Short)
                    .setRequired(true).setValue(prefill.itemName ?? ''),
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('itemType').setLabel('Type').setStyle(TextInputStyle.Short)
                    .setRequired(false).setValue(prefill.itemType ?? ''),
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('itemSubtype').setLabel('Subtype').setStyle(TextInputStyle.Short)
                    .setRequired(false).setValue(prefill.itemSubtype ?? ''),
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('itemRarity').setLabel('Rarity').setStyle(TextInputStyle.Short)
                    .setRequired(false).setValue(prefill.itemRarity ?? ''),
            ),
            new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('itemValue').setLabel('Value (gp)').setStyle(TextInputStyle.Short)
                    .setRequired(false).setValue(prefill.itemValue ?? ''),
            ),
        );
    return modal;
}

async function handleAddItemActionSelect(interaction, questId, extra) {
    const [characterPageId, dashboardMessageId] = extra.split('|');
    const action = interaction.values[0];

    if (action === 'add') {
        const select = new StringSelectMenuBuilder()
            .setCustomId(encodeId(questId, 'addItemSource', `${characterPageId}|${dashboardMessageId}`))
            .setPlaceholder('How do you want to add this item?')
            .addOptions(
                { label: 'Search Catalogue', value: 'catalogue', emoji: '📖' },
                { label: 'Manual Entry',     value: 'manual',    emoji: '✏️' },
            );
        return interaction.update({
            content: 'Search the 5etools catalogue, or enter the item manually?',
            components: [new ActionRowBuilder().addComponents(select)],
        });
    }

    // remove
    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    const itemLines = state.draft.lines.filter(l => l.type === 'item' && l.characterPageId === characterPageId);
    if (itemLines.length === 0) {
        return interaction.update({ content: 'This character has no items queued yet.', components: [] });
    }

    const select = new StringSelectMenuBuilder()
        .setCustomId(encodeId(questId, 'addItemRemoveSelect', `${characterPageId}|${dashboardMessageId}`))
        .setPlaceholder('Which item to remove?')
        .addOptions(itemLines.slice(0, 25).map(l => ({
            label: (l.payload.itemName ?? 'Unknown item').slice(0, 100),
            value: l.lineId,
        })));

    return interaction.update({
        content: 'Which item should be removed?',
        components: [new ActionRowBuilder().addComponents(select)],
    });
}

async function handleAddItemSourceSelect(interaction, questId, extra) {
    const [characterPageId, dashboardMessageId] = extra.split('|');
    const source = interaction.values[0];

    if (source === 'manual') {
        return interaction.showModal(buildManualItemModal(questId, characterPageId, dashboardMessageId, 'manual'));
    }

    // catalogue
    const modal = new ModalBuilder()
        .setCustomId(encodeId(questId, 'addItemSearch', `${characterPageId}|${dashboardMessageId}`))
        .setTitle('Search Catalogue')
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('query').setLabel('Item name (or part of it)')
                    .setStyle(TextInputStyle.Short).setRequired(true),
            ),
        );
    return interaction.showModal(modal);
}

async function handleAddItemRetrySearch(interaction, questId, extra) {
    const modal = new ModalBuilder()
        .setCustomId(encodeId(questId, 'addItemSearch', extra))
        .setTitle('Search Catalogue')
        .addComponents(
            new ActionRowBuilder().addComponents(
                new TextInputBuilder().setCustomId('query').setLabel('Item name (or part of it)')
                    .setStyle(TextInputStyle.Short).setRequired(true),
            ),
        );
    return interaction.showModal(modal);
}

async function handleAddItemSearchModalSubmit(interaction, questId, extra) {
    const [characterPageId, dashboardMessageId] = extra.split('|');
    const query = interaction.fields.getTextInputValue('query').trim();

    if (!query) {
        return interaction.reply({ content: '❌ Enter something to search for.', flags: 64 });
    }

    const matches = searchCatalogue(query, { limit: 25 });

    if (matches.length === 0) {
        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId(encodeId(questId, 'addItemRetrySearch', `${characterPageId}|${dashboardMessageId}`))
                .setLabel('Search Again')
                .setStyle(ButtonStyle.Secondary),
        );
        return interaction.reply({
            content: `❌ No catalogue matches for "${query}". Try a different search, or reopen Add Item and pick Manual Entry instead.`,
            components: [row],
            flags: 64,
        });
    }

    const select = new StringSelectMenuBuilder()
        .setCustomId(encodeId(questId, 'addItemCatalogueSelect', `${characterPageId}|${dashboardMessageId}`))
        .setPlaceholder('Which item?')
        .addOptions(matches.map(item => ({
            label: item.name.slice(0, 100),
            description: `${item.rarity} ${item.type} — ${formatCurrency(item.priceGp ?? defaultPriceFor(item.rarity))}`.slice(0, 100),
            value: item.code,
        })));

    return interaction.reply({
        content: `Found ${matches.length} match(es) for "${query}":`,
        components: [new ActionRowBuilder().addComponents(select)],
        flags: 64,
    });
}

async function handleAddItemCatalogueSelect(interaction, questId, extra) {
    const [characterPageId, dashboardMessageId] = extra.split('|');
    const code = interaction.values[0];
    const item = getCatalogueItemByCode(code);

    if (!item) {
        return interaction.update({ content: '❌ That item is no longer in the catalogue. Try searching again.', components: [] });
    }

    const prefill = {
        itemName: item.name,
        itemType: item.type ?? '',
        itemSubtype: inferSubtype(item) ?? '',
        itemRarity: item.rarity ?? '',
        itemValue: item.priceGp != null ? String(item.priceGp) : String(defaultPriceFor(item.rarity)),
    };

    return interaction.showModal(buildManualItemModal(questId, characterPageId, dashboardMessageId, 'catalogue', prefill));
}

async function handleAddItemModalSubmit(interaction, questId, extra) {
    const [characterPageId, dashboardMessageId, sourceTag] = extra.split('|');

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.reply({ content: err.message, flags: 64 });
    }

    const character = state.roster.find(c => c.characterPageId === characterPageId);
    if (!character) {
        return interaction.reply({ content: '❌ That character is no longer on this quest\'s roster.', flags: 64 });
    }

    const itemName = interaction.fields.getTextInputValue('itemName').trim();
    const itemType = interaction.fields.getTextInputValue('itemType').trim() || null;
    const itemSubtype = interaction.fields.getTextInputValue('itemSubtype').trim() || null;
    const itemRarity = interaction.fields.getTextInputValue('itemRarity').trim() || null;
    const rawValue = interaction.fields.getTextInputValue('itemValue').trim();

    let itemValue = null;
    if (rawValue !== '') {
        itemValue = Number(rawValue);
        if (isNaN(itemValue)) {
            return interaction.reply({ content: `❌ "${rawValue}" isn't a valid number for Value (gp).`, flags: 64 });
        }
    }

    const source = sourceTag === 'catalogue' ? 'Dashboard (catalogue)' : 'Dashboard (manual entry)';

    questDrafts.addOrReplaceLine(questId, {
        characterPageId: character.characterPageId,
        characterName: character.characterName,
        discordId: character.discordId,
        type: 'item',
        payload: {
            itemName, type: itemType, subtype: itemSubtype, rarity: itemRarity, itemValue,
            source, notes: null,
        },
    });

    await refreshDashboardMessage(interaction, questId, dashboardMessageId);
    return interaction.reply({ content: `✅ **${itemName}** added for **${character.characterName}**.`, flags: 64 });
}

async function handleAddItemRemoveSelect(interaction, questId, extra) {
    const [characterPageId, dashboardMessageId] = extra.split('|');
    const lineId = interaction.values[0];

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    questDrafts.removeLine(questId, lineId);
    await refreshDashboardMessage(interaction, questId, dashboardMessageId);
    return interaction.update({ content: '🗑️ Item removed.', components: [] });
}

// Edit Party — entry point: choose Add or Remove

async function handleEditParty(interaction, questId) {
    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.reply({ content: err.message, flags: 64 });
    }

    const dashboardMessageId = interaction.message.id;
    const select = new StringSelectMenuBuilder()
        .setCustomId(encodeId(questId, 'partyAction', dashboardMessageId))
        .setPlaceholder('Add or remove a party member?')
        .addOptions(
            { label: 'Add Character',    value: 'add',    emoji: '➕' },
            { label: 'Remove Character', value: 'remove', emoji: '➖' },
        );

    return interaction.reply({
        content: 'Add a character to the roster, or remove one?',
        components: [new ActionRowBuilder().addComponents(select)],
        flags: 64,
    });
}

async function handlePartyActionSelect(interaction, questId, dashboardMessageId) {
    const action = interaction.values[0];

    if (action === 'add') {
        const select = new UserSelectMenuBuilder()
            .setCustomId(encodeId(questId, 'partyAddUser', dashboardMessageId))
            .setPlaceholder('Which player?');

        return interaction.update({
            content: 'Select the player whose **active character** should be added.',
            components: [new ActionRowBuilder().addComponents(select)],
        });
    }

    // remove
    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    if (state.roster.length === 0) {
        return interaction.update({ content: 'This quest has no characters on the roster yet.', components: [] });
    }

    const options = [
        { label: '🗑️ Remove All Characters', value: '__all__', description: `Clears all ${state.roster.length} character(s) and their queued rewards` },
        ...state.roster.slice(0, 24).map(c => ({ label: c.characterName.slice(0, 100), value: c.characterPageId })),
    ];

    const select = new StringSelectMenuBuilder()
        .setCustomId(encodeId(questId, 'partyRemoveSelect', dashboardMessageId))
        .setPlaceholder('Which character to remove?')
        .addOptions(options);

    return interaction.update({
        content: 'Which character should be removed from the roster?',
        components: [new ActionRowBuilder().addComponents(select)],
    });
}

// Edit Party — Add: resolve active character, confirm

async function handlePartyAddUserSelect(interaction, questId, dashboardMessageId) {
    const userId = interaction.values[0];

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    const character = await getActiveCharacter(userId).catch(() => null);
    if (!character) {
        return interaction.update({
            content: `❌ <@${userId}> has no active character. Ask them to set one before adding them to this quest.`,
            components: [],
        });
    }

    const charName = character.properties['Character Name']?.title?.[0]?.plain_text ?? 'Unknown';

    if (state.roster.some(c => c.characterPageId === character.id)) {
        return interaction.update({ content: `⚠️ **${charName}** is already on this quest's roster.`, components: [] });
    }

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'partyAddConfirm', `${character.id}|${dashboardMessageId}`))
            .setLabel('Confirm')
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'partyAddCancel', dashboardMessageId))
            .setLabel('Cancel')
            .setStyle(ButtonStyle.Secondary),
    );

    return interaction.update({
        content: `This will add **${charName}** — <@${userId}>'s active character — to the roster. Is this correct?\n` +
            `If not, ask <@${userId}> to switch their active character to the right one and try again.`,
        components: [row],
    });
}

async function handlePartyAddConfirm(interaction, questId, extra) {
    const [characterId, dashboardMessageId] = extra.split('|');

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    let result;
    try {
        result = await addCharacterToRoster(state.quest, characterId);
    } catch (err) {
        console.error(`[questDashboard] Error adding character ${characterId} to quest ${questId}:`, err);
        return interaction.update({ content: '❌ Failed to add character — check logs.', components: [] });
    }

    await refreshDashboardMessage(interaction, questId, dashboardMessageId);

    return interaction.update({
        content: result.alreadyPresent ? '⚠️ Already on the roster — nothing changed.' : '✅ Character added to the roster.',
        components: [],
    });
}

async function handlePartyAddCancel(interaction) {
    return interaction.update({ content: 'Cancelled — nothing changed.', components: [] });
}

// Edit Party — Remove: confirm (with cascade warning if lines exist), then apply

async function handlePartyRemoveSelect(interaction, questId, dashboardMessageId) {
    const target = interaction.values[0];

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'partyRemoveConfirm', `${target}|${dashboardMessageId}`))
            .setLabel('Confirm')
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId(encodeId(questId, 'partyRemoveCancel', dashboardMessageId))
            .setLabel('Cancel')
            .setStyle(ButtonStyle.Secondary),
    );

    if (target === '__all__') {
        const lineCount = state.draft.lines.length;
        const warning = lineCount > 0
            ? `Removing all characters will also remove all **${lineCount}** queued reward line(s). `
            : '';
        return interaction.update({
            content: `⚠️ Are you sure you want to remove **all ${state.roster.length} character(s)** from this quest's roster? ${warning}This cannot be undone.`,
            components: [row],
        });
    }

    const character = state.roster.find(c => c.characterPageId === target);
    if (!character) {
        return interaction.update({ content: '❌ That character is no longer on the roster.', components: [] });
    }

    const lineCount = state.draft.lines.filter(l => l.characterPageId === target).length;
    const warning = lineCount > 0
        ? `⚠️ Removing **${character.characterName}** will also remove their **${lineCount}** queued reward line(s). Remove anyway?`
        : `Remove **${character.characterName}** from the roster?`;

    return interaction.update({ content: warning, components: [row] });
}

async function handlePartyRemoveConfirm(interaction, questId, extra) {
    const [target, dashboardMessageId] = extra.split('|');

    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
        assertUnlocked(state);
    } catch (err) {
        return interaction.update({ content: err.message, components: [] });
    }

    const characterIds = target === '__all__'
        ? state.roster.map(c => c.characterPageId)
        : [target];

    try {
        await removeCharactersFromRoster(state.quest, characterIds);
    } catch (err) {
        console.error(`[questDashboard] Error removing character(s) ${characterIds.join(',')} from quest ${questId}:`, err);
        return interaction.update({ content: '❌ Failed to update the roster — check logs.', components: [] });
    }

    for (const line of state.draft.lines) {
        if (characterIds.includes(line.characterPageId)) {
            questDrafts.removeLine(questId, line.lineId);
        }
    }

    await refreshDashboardMessage(interaction, questId, dashboardMessageId);

    return interaction.update({
        content: target === '__all__'
            ? '✅ All characters removed from the roster.'
            : '✅ Character removed from the roster.',
        components: [],
    });
}

async function handlePartyRemoveCancel(interaction) {
    return interaction.update({ content: 'Cancelled — nothing changed.', components: [] });
}

// Grouping toggle — re-renders the dashboard message itself in place

async function handleToggleGroup(interaction, questId, grouping) {
    let state;
    try {
        state = await loadDashboardState(questId, {
            discordId: interaction.user.id,
            username: interaction.user.username,
        });
        assertOwner(state, interaction);
    } catch (err) {
        return interaction.reply({ content: err.message, flags: 64 });
    }

    return interaction.update(renderMainView(state.draft, state.roster, { grouping }));
}

// Dispatch

async function handleDashboardButton(interaction) {
    const { questId, action, extra } = decodeId(interaction.customId);

    if (action === 'submit')            return handleSubmit(interaction, questId);
    if (action === 'submitConfirm')     return handleSubmitConfirm(interaction, questId, extra);
    if (action === 'submitCancel')      return handleSubmitCancel(interaction);
    if (action === 'addReward')         return handleAddReward(interaction, questId);
    if (action === 'addRewardBulkNext') return handleAddRewardBulkNext(interaction, questId, extra);
    if (action === 'addItemRetrySearch') return handleAddItemRetrySearch(interaction, questId, extra);
    if (action === 'editParty')         return handleEditParty(interaction, questId);
    if (action === 'partyAddConfirm')   return handlePartyAddConfirm(interaction, questId, extra);
    if (action === 'partyAddCancel')    return handlePartyAddCancel(interaction);
    if (action === 'partyRemoveConfirm') return handlePartyRemoveConfirm(interaction, questId, extra);
    if (action === 'partyRemoveCancel') return handlePartyRemoveCancel(interaction);
    if (action === 'toggleGroup')       return handleToggleGroup(interaction, questId, extra);

    return interaction.reply({ content: '❌ This dashboard control isn\'t wired up yet.', flags: 64 });
}

async function handleDashboardSelect(interaction) {
    const { questId, action, extra } = decodeId(interaction.customId);

    if (action === 'addRewardType')       return handleAddRewardTypeSelect(interaction, questId, extra);
    if (action === 'addItemPlayer')       return handleAddItemPlayerSelect(interaction, questId, extra);
    if (action === 'addItemAction')       return handleAddItemActionSelect(interaction, questId, extra);
    if (action === 'addItemRemoveSelect') return handleAddItemRemoveSelect(interaction, questId, extra);
    if (action === 'addItemSource')       return handleAddItemSourceSelect(interaction, questId, extra);
    if (action === 'addItemCatalogueSelect') return handleAddItemCatalogueSelect(interaction, questId, extra);
    if (action === 'partyAction')         return handlePartyActionSelect(interaction, questId, extra);
    if (action === 'partyRemoveSelect')   return handlePartyRemoveSelect(interaction, questId, extra);

    return interaction.reply({ content: '❌ This dashboard control isn\'t wired up yet.', flags: 64 });
}

async function handleDashboardUserSelect(interaction) {
    const { questId, action, extra } = decodeId(interaction.customId);

    if (action === 'partyAddUser') return handlePartyAddUserSelect(interaction, questId, extra);

    return interaction.reply({ content: '❌ This dashboard control isn\'t wired up yet.', flags: 64 });
}

async function handleDashboardModal(interaction) {
    const { questId, action, extra } = decodeId(interaction.customId);

    if (action === 'addRewardBulk') return handleAddRewardBulkModalSubmit(interaction, questId, extra);
    if (action === 'addItemModal')  return handleAddItemModalSubmit(interaction, questId, extra);
    if (action === 'addItemSearch') return handleAddItemSearchModalSubmit(interaction, questId, extra);

    return interaction.reply({ content: '❌ This dashboard control isn\'t wired up yet.', flags: 64 });
}

module.exports = {
    prefix: { 'questDash:': handleDashboardButton },
    handleDashboardSelect,
    handleDashboardUserSelect,
    handleDashboardModal,
};
